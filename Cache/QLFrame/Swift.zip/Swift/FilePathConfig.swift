//
//  FilePathConfig.swift
//  Ev
//
//  Created by 王青海 on 16/5/25.
//  Copyright © 2016年 王青海. All rights reserved.
//

import Foundation


public struct FilePathConfig {
    
    
    
    

}



