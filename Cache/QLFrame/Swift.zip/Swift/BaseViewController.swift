//
//  BaseViewController.swift
//  Ev
//
//  Created by 王青海 on 16/5/25.
//  Copyright © 2016年 王青海. All rights reserved.
//

import UIKit

public class BaseViewController: UIViewController {

    public override func viewDidLoad() {
        super.viewDidLoad()
        
        self.automaticallyAdjustsScrollViewInsets = false
        self.navigationController?.navigationBar.translucent = false
    }
    
    
    
    
    
    
}
