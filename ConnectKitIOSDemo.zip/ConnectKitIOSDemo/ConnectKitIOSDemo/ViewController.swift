//
//  ViewController.swift
//  ConnectKitIOSDemo
//
//  Created by CaiLianfeng on 16/8/28.
//  Copyright © 2016年 WangQinghai. All rights reserved.
//

import UIKit

import ConnectKit


class ViewController: UIViewController {

    var connect: SocketConnect!

    
    @IBOutlet weak var titleLabel: UILabel!
    
    
    @IBOutlet weak var ip: UITextField!
    
    
    @IBOutlet weak var portTextField: UITextField!
    
    @IBOutlet weak var debugTextView: UITextView!
    
    
    @IBOutlet weak var messageTextField: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.connect = SocketConnect()
        connect.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func connectButtonClicked(sender: UIButton) {
        connect.connect("192.168.0.103", port: 6666, tlsSettings: nil)
    }
    
    @IBOutlet weak var sendButtonClicked: UIButton!
    
    
    @IBAction func sendButtonClieked(sender: AnyObject) {
        var message: String = ""
        if let str = self.messageTextField.text {
            message = str
        }
        
        self.messageTextField.text = ""
        
        let data = message.dataUsingEncoding(NSUTF8StringEncoding)!
        
        let item = SocketConnect.DataItem(data: data)
        connect.writeToConnect(item, waitingTimeout: 10, successClosure: { (connect, item) in
            print("write success call back")
            }, timeoutClosure: { (connect, item) in
                print("write timeout call back")
            }) { (connect, item) in
                print("write failure call back")
        }
        
    }
}


extension ViewController: ConnectDelegate {
    func connectSuccess(connect: SocketConnect) {
        
    }
    func connectFailure(connect: SocketConnect, error: NSError) {
        
    }
    func connectClosed(connect: SocketConnect, error: NSError?) {
        
    }
    func connectDidReceiveData(connect: SocketConnect, data: NSData) {
        if let str = String(data: data, encoding: NSUTF8StringEncoding) {
            self.debugTextView.text = self.debugTextView.text! + str
        }
    }
}






